<a name="1.0.2"></a>
## 1.0.2 (2016-05-18)


### Bug Fixes

* **sorting:** it does not allow multiple columns to sort (fixes [#40](https://github.com/valor-software/ng2-table/issues/40)) ([47256a6](https://github.com/valor-software/ng2-table/commit/47256a6)), closes [#40](https://github.com/valor-software/ng2-table/issues/40)


### Features

* **build:** ng-tables updated to common: ([91c07af](https://github.com/valor-software/ng2-table/commit/91c07af))
* **options:** Allow access to properties that are deeper down the object tree. (fixes [#81](https://github.com/valor-software/ng2-table/issues/81)) ([b7de4ad](https://github.com/valor-software/ng2-table/commit/b7de4ad)), closes [#81](https://github.com/valor-software/ng2-table/issues/81)
* **package:** update to angular 2 rc1 ([#140](https://github.com/valor-software/ng2-table/issues/140)) ([2cade91](https://github.com/valor-software/ng2-table/commit/2cade91))


### BREAKING CHANGES

* build: S:
- selector changed from to ngTable to ng-table



